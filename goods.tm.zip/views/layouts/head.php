<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="/template/css/header.css">
<link rel="stylesheet" href="/template/css/main.css">
<link rel="stylesheet" href="/template/css/description.css">
<link rel="stylesheet" href="/template/css/sidebar.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
<script type="text/javascript" src="/template/js/sidebar.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
