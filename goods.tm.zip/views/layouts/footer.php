<footer class="footer">

</footer>

<script src="/template/js/AJAX.js"></script>