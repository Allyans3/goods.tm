<header class="header">
    <div class="right-header">
        <a class="burger-btn">
            <span></span>
            <span></span>
            <span></span>
        </a>
        <i class="fas fa-circle"></i>
        <p>Online</p>
    </div>

    <div class="logout">
        <p>a.sylenok@gmail.com</p>
        <a href="/logout"><i class="fas fa-sign-out-alt"></i></a>
    </div>
</header>