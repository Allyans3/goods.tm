<?php

class Db
{
    public static function getConnection() {
        $server = 'remotemysql.com';
        $dbname = '0EhqmC71No';
        $user = '0EhqmC71No';
        $pass = 'o8F07QaCns';

        try {
            $db = new PDO("mysql:host=$server; dbname=$dbname", $user, $pass ,
                array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ));
            $db->exec("set names utf8");
            echo "We connected.";
            return $db;
        } catch (PDOException $e) {
            print($e->getMessage());
        }

    }
}


?>
